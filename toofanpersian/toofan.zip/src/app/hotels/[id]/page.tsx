import { Metadata } from "next";
import { notFound } from "next/navigation";
import { hotels, getHotelById } from "@/lib/data/hotels";
import { Header } from "@/components/layout/header";
import HotelGallery from "@/components/hotels/HotelGallery";
import HotelInfo from "@/components/hotels/HotelInfo";
import HotelAmenities from "@/components/hotels/HotelAmenities";
import HotelRooms from "@/components/hotels/HotelRooms";
import HotelReviews from "@/components/hotels/HotelReviews";
import HotelMap from "@/components/hotels/HotelMap";
import HotelSidebar from "@/components/hotels/HotelSidebar";
import HotelSimilar from "@/components/hotels/HotelSimilar";
import HotelsCTA from "@/components/hotels/HotelsCTA";
import Footer from "@/components/layout/footer";

interface PageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const hotel = getHotelById(id);
  if (!hotel) return { title: "هتل یافت نشد" };
  return {
    title: `${hotel.name} | طوفان پرشین`,
    description: hotel.description,
  };
}

export async function generateStaticParams() {
  return hotels.map((hotel) => ({ id: hotel.id }));
}

export default async function HotelDetailPage({ params }: PageProps) {
  const { id } = await params;
  const hotel = getHotelById(id);
  if (!hotel) notFound();

  return (
    <main className="min-h-screen bg-slate-50">
      <Header />

      {/* Main Content */}
      <div className="container-brand px-4 py-6 md:py-8">
        {/* Gallery */}
        <HotelGallery images={hotel.gallery} hotelName={hotel.name} />

        {/* 2 Column Layout */}
        <div className="flex gap-6 mt-6">
          {/* Left Column - Main Content */}
          <div className="flex-1 min-w-0 space-y-6">
            <HotelInfo hotel={hotel} />
            
            {/* About */}
            <div className="bg-white rounded-2xl border border-slate-100 p-5 md:p-7">
              <h2 className="text-lg md:text-xl font-black text-navy-900 mb-4">
                درباره این هتل
              </h2>
              <p className="text-sm md:text-base text-slate-700 leading-loose">
                {hotel.description}
              </p>
              
              {/* Highlights */}
              <div className="mt-5 pt-5 border-t border-slate-100">
                <h3 className="text-sm font-bold text-navy-900 mb-3">
                  چرا این هتل را انتخاب کنید؟
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {hotel.highlights.map((h, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-slate-700">
                      <div className="w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                        <div className="w-2 h-2 rounded-full bg-emerald-600" />
                      </div>
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <HotelAmenities hotel={hotel} />
            <HotelRooms rooms={hotel.rooms} />
            <HotelReviews
              reviews={hotel.reviews}
              averageRating={hotel.rating}
              totalReviews={hotel.reviewCount}
            />
            <HotelMap
              coordinates={hotel.coordinates}
              address={hotel.address}
              name={hotel.name}
            />
          </div>

          {/* Right Column - Sidebar */}
          <HotelSidebar hotel={hotel} />
        </div>
      </div>

      <HotelsCTA />
      <HotelSimilar hotels={hotels} currentHotelId={hotel.id} />
      <Footer />
    </main>
  );
}