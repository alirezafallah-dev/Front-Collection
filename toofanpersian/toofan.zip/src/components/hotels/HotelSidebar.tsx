"use client";

import { Phone, MessageCircle, Mail, Clock, MapPin } from "lucide-react";
import { Hotel } from "@/lib/data/hotels";

interface HotelSidebarProps {
  hotel: Hotel;
}

export default function HotelSidebar({ hotel }: HotelSidebarProps) {
  return (
    <aside className="hidden lg:block w-80 flex-shrink-0">
      <div className="sticky top-24 space-y-4">
        {/* Contact Card */}
        <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
          <h3 className="text-base font-black text-navy-900 mb-4">
            تماس با هتل
          </h3>
          
          <div className="space-y-3 mb-5">
            <a
              href={`tel:${hotel.phone}`}
              className="flex items-center gap-3 p-3 rounded-xl bg-brand-50 hover:bg-brand-100 transition-colors group"
            >
              <div className="w-10 h-10 rounded-lg bg-brand-500 flex items-center justify-center flex-shrink-0">
                <Phone className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-slate-500">تلفن هتل</div>
                <div className="text-sm font-bold text-navy-900 truncate" dir="ltr">
                  {hotel.phone}
                </div>
              </div>
            </a>

            <a
              href="https://wa.me/989120000000"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 transition-colors group"
            >
              <div className="w-10 h-10 rounded-lg bg-emerald-500 flex items-center justify-center flex-shrink-0">
                <MessageCircle className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-slate-500">واتساپ</div>
                <div className="text-sm font-bold text-navy-900">مشاوره رایگان</div>
              </div>
            </a>

            <a
              href={`mailto:info@toofantravel.com`}
              className="flex items-center gap-3 p-3 rounded-xl bg-blue-50 hover:bg-blue-100 transition-colors group"
            >
              <div className="w-10 h-10 rounded-lg bg-blue-500 flex items-center justify-center flex-shrink-0">
                <Mail className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-slate-500">ایمیل</div>
                <div className="text-sm font-bold text-navy-900 truncate">
                  info@toofantravel.com
                </div>
              </div>
            </a>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <div className="flex items-start gap-2 text-xs text-slate-600">
              <MapPin className="w-4 h-4 text-brand-500 flex-shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-navy-900 mb-0.5">آدرس</div>
                <div className="leading-relaxed">{hotel.address}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Help Card */}
        <div className="bg-gradient-to-br from-navy-900 to-navy-800 rounded-2xl p-5 text-white">
          <div className="w-10 h-10 rounded-lg bg-brand-500 flex items-center justify-center mb-3">
            <Clock className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-base font-bold mb-2">
            نیاز به راهنمایی دارید؟
          </h3>
          <p className="text-xs text-white/70 leading-relaxed mb-4">
            کارشناسان ما آماده پاسخگویی به سوالات شما درباره این هتل هستند.
          </p>
          <a
            href="tel:02191000000"
            className="block w-full text-center py-2.5 rounded-lg bg-brand-500 hover:bg-brand-600 text-white text-sm font-bold transition-colors"
          >
            تماس با طوفان پرشین
          </a>
        </div>
      </div>
    </aside>
  );
}