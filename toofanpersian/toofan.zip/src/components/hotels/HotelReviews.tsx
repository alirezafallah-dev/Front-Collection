"use client";

import { Star } from "lucide-react";
import Image from "next/image";
import { HotelReview } from "@/lib/data/hotels";

interface HotelReviewsProps {
  reviews: HotelReview[];
  averageRating: number;
  totalReviews: string;
}

export default function HotelReviews({ reviews, averageRating, totalReviews }: HotelReviewsProps) {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-black text-navy-900 mb-1">
            نظرات مسافران
          </h2>
          <p className="text-xs text-slate-500">
            بر اساس {totalReviews} نظر
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-brand-50">
          <Star className="w-5 h-5 text-brand-500 fill-brand-500" />
          <span className="text-xl font-black text-brand-600">{averageRating}</span>
        </div>
      </div>

      <div className="space-y-4">
        {reviews.map((review) => (
          <div
            key={review.id}
            className="p-4 rounded-xl bg-slate-50 hover:bg-slate-100/70 transition-colors"
          >
            <div className="flex items-start gap-3 mb-3">
              <div className="relative w-11 h-11 rounded-full overflow-hidden flex-shrink-0">
                <Image
                  src={review.avatar}
                  alt={review.author}
                  fill
                  sizes="44px"
                  className="object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-sm text-navy-900">
                      {review.author}
                    </div>
                    <div className="text-xs text-slate-500">
                      {review.tripType} • {review.date}
                    </div>
                  </div>
                  <div className="flex items-center gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < review.rating
                            ? "text-yellow-400 fill-yellow-400"
                            : "text-slate-300"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <h4 className="text-sm font-bold text-navy-900 mb-1">
              {review.title}
            </h4>
            <p className="text-sm text-slate-600 leading-relaxed">
              {review.comment}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}