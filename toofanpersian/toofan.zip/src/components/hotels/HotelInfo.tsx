"use client";

import { Star, MapPin, Share2, Heart, Award, Check } from "lucide-react";
import { Hotel } from "@/lib/data/hotels";
import HotelBreadcrumb from "./HotelBreadcrumb";
import { useState } from "react";

interface HotelInfoProps {
  hotel: Hotel;
}

export default function HotelInfo({ hotel }: HotelInfoProps) {
  const [isSaved, setIsSaved] = useState(false);

  const countrySlug = 
    hotel.country === "turkey" ? "istanbul" :
    hotel.country === "thailand" ? "thailand" :
    "russia";
  
  const city = hotel.location.split("،")[0];

  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-5 md:p-7">
      {/* Breadcrumb */}
      <div className="mb-4">
        <HotelBreadcrumb
          country={hotel.country === "turkey" ? "ترکیه" : hotel.country === "thailand" ? "تایلند" : "روسیه"}
          countrySlug={countrySlug}
          city={city}
          hotelName={hotel.name}
        />
      </div>

      {/* Title + Meta */}
      <div className="mb-5">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">{hotel.flag}</span>
              <h1 className="text-xl md:text-3xl font-black text-navy-900 leading-tight">
                {hotel.name}
              </h1>
            </div>
            
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-600">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-brand-500" />
                <span>{hotel.location}</span>
                <span className="text-slate-300">•</span>
                <span className="font-medium text-slate-700">{hotel.neighborhood}</span>
              </div>
              <div className="flex items-center gap-1">
                {[...Array(hotel.stars)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                ))}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={() => setIsSaved(!isSaved)}
              className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
                isSaved
                  ? "bg-red-50 text-red-500"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
              aria-label="ذخیره"
            >
              <Heart className={`w-5 h-5 ${isSaved ? "fill-current" : ""}`} />
            </button>
            <button
              className="w-11 h-11 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors"
              aria-label="اشتراک‌گذاری"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Rating Badge - Airbnb Style */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-navy-900 text-white flex items-center justify-center text-base font-black">
              {hotel.rating}
            </div>
            <div>
              <div className="text-sm font-bold text-navy-900">
                {hotel.rating >= 4.8 ? "فوق‌العاده" : hotel.rating >= 4.5 ? "عالی" : "خیلی خوب"}
              </div>
              <div className="text-xs text-slate-500">
                {hotel.reviewCount} نظر
              </div>
            </div>
          </div>
          
          {hotel.featured && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-brand-50 text-brand-700 text-xs font-bold">
              <Award className="w-3.5 h-3.5" />
              <span>پیشنهاد ویژه طوفان پرشین</span>
            </div>
          )}
        </div>
      </div>

      {/* Highlights - Quick Features */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-5 border-t border-slate-100">
        <div className="flex items-start gap-2">
          <div className="w-8 h-8 rounded-lg bg-brand-50 flex items-center justify-center flex-shrink-0">
            <MapPin className="w-4 h-4 text-brand-600" />
          </div>
          <div>
            <div className="text-xs text-slate-500">محله</div>
            <div className="text-sm font-bold text-navy-900">{hotel.neighborhood}</div>
          </div>
        </div>
        
        <div className="flex items-start gap-2">
          <div className="w-8 h-8 rounded-lg bg-brand-50 flex items-center justify-center flex-shrink-0">
            <Star className="w-4 h-4 text-brand-600" />
          </div>
          <div>
            <div className="text-xs text-slate-500">درجه هتل</div>
            <div className="text-sm font-bold text-navy-900">{hotel.stars} ستاره</div>
          </div>
        </div>

        <div className="flex items-start gap-2">
          <div className="w-8 h-8 rounded-lg bg-brand-50 flex items-center justify-center flex-shrink-0">
            <Check className="w-4 h-4 text-brand-600" />
          </div>
          <div>
            <div className="text-xs text-slate-500">Check-in</div>
            <div className="text-sm font-bold text-navy-900">{hotel.checkIn}</div>
          </div>
        </div>

        <div className="flex items-start gap-2">
          <div className="w-8 h-8 rounded-lg bg-brand-50 flex items-center justify-center flex-shrink-0">
            <Check className="w-4 h-4 text-brand-600" />
          </div>
          <div>
            <div className="text-xs text-slate-500">Check-out</div>
            <div className="text-sm font-bold text-navy-900">{hotel.checkOut}</div>
          </div>
        </div>
      </div>
    </div>
  );
}