"use client";

import { useState } from "react";
import Image from "next/image";
import { X, ChevronRight, ChevronLeft, Camera, Maximize2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface HotelGalleryProps {
  images: string[];
  hotelName: string;
}

export default function HotelGallery({ images, hotelName }: HotelGalleryProps) {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);

  const displayImages = images.slice(0, 5);
  const hasMore = images.length > 5;
  const remainingCount = images.length - 5;

  const openLightbox = (index: number) => {
    setActiveIndex(index);
    setLightboxOpen(true);
  };

  const closeLightbox = () => setLightboxOpen(false);

  const nextImage = () => setActiveIndex((prev) => (prev + 1) % images.length);
  const prevImage = () => setActiveIndex((prev) => (prev - 1 + images.length) % images.length);

  return (
    <>
      {/* Gallery Container */}
      <div className="w-full">
        {/* Desktop Layout - Airbnb Style */}
        <div className="hidden md:grid md:grid-cols-4 md:grid-rows-2 gap-2 h-[420px] lg:h-[480px] rounded-2xl overflow-hidden">
          {/* Main Image - Large */}
          <button
            onClick={() => openLightbox(0)}
            className="col-span-2 row-span-2 relative group cursor-pointer overflow-hidden"
          >
            <Image
              src={displayImages[0]}
              alt={`${hotelName} - عکس اصلی`}
              fill
              sizes="50vw"
              className="object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
          </button>

          {/* 4 Secondary Images in Grid */}
          {displayImages.slice(1, 5).map((img, i) => (
            <button
              key={i}
              onClick={() => openLightbox(i + 1)}
              className="relative group cursor-pointer overflow-hidden"
            >
              <Image
                src={img}
                alt={`${hotelName} - عکس ${i + 2}`}
                fill
                sizes="25vw"
                className="object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
              
              {/* "Show all photos" overlay on last image */}
              {i === 3 && hasMore && (
                <div
                  className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    openLightbox(4);
                  }}
                >
                  <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white text-navy-900 text-sm font-bold">
                    <Camera className="w-4 h-4" />
                    <span>نمایش همه ({images.length} عکس)</span>
                  </div>
                </div>
              )}
            </button>
          ))}
        </div>

        {/* Mobile Layout - Single Image + Counter */}
        <div className="md:hidden relative h-72 rounded-2xl overflow-hidden">
          <Image
            src={displayImages[0]}
            alt={`${hotelName} - عکس اصلی`}
            fill
            sizes="100vw"
            className="object-cover"
          />
          
          {/* Show all photos button */}
          <button
            onClick={() => openLightbox(0)}
            className="absolute bottom-4 left-4 flex items-center gap-2 px-4 py-2 rounded-lg bg-white/95 backdrop-blur-sm text-navy-900 text-xs font-bold shadow-lg"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>{images.length} عکس</span>
          </button>
        </div>
      </div>

      {/* Lightbox Modal */}
      {lightboxOpen && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col">
          {/* Lightbox Header */}
          <div className="flex items-center justify-between px-4 md:px-6 py-4 bg-black/90 backdrop-blur-sm">
            <div className="text-white text-sm font-medium">
              <span className="font-bold">{activeIndex + 1}</span>
              <span className="text-white/60"> از {images.length}</span>
            </div>
            <button
              onClick={closeLightbox}
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
              aria-label="بستن"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Lightbox Content */}
          <div className="flex-1 relative flex items-center justify-center p-4 md:p-10">
            {/* Prev Button */}
            <button
              onClick={prevImage}
              className="absolute left-2 md:left-6 top-1/2 -translate-y-1/2 w-11 h-11 md:w-12 md:h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white flex items-center justify-center transition-all z-10"
              aria-label="عکس قبلی"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Image */}
            <div className="relative w-full h-full max-w-6xl flex items-center justify-center">
              <Image
                src={images[activeIndex]}
                alt={`${hotelName} - عکس ${activeIndex + 1}`}
                fill
                sizes="100vw"
                className="object-contain"
                priority
              />
            </div>

            {/* Next Button */}
            <button
              onClick={nextImage}
              className="absolute right-2 md:right-6 top-1/2 -translate-y-1/2 w-11 h-11 md:w-12 md:h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white flex items-center justify-center transition-all z-10"
              aria-label="عکس بعدی"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          </div>

          {/* Thumbnail Strip */}
          <div className="bg-black/90 backdrop-blur-sm px-4 md:px-6 py-4 overflow-x-auto">
            <div className="flex gap-2 justify-center">
              {images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveIndex(i)}
                  className={cn(
                    "relative w-16 h-16 md:w-20 md:h-20 rounded-lg overflow-hidden flex-shrink-0 transition-all",
                    activeIndex === i
                      ? "ring-2 ring-white opacity-100"
                      : "opacity-50 hover:opacity-80"
                  )}
                >
                  <Image src={img} alt="" fill sizes="80px" className="object-cover" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}